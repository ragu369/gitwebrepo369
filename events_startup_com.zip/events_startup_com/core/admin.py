from django.contrib import admin
from material.admin.options import MaterialModelAdmin
from material.admin.sites import site
from .models import Product, Order, CartItem, LineItem

# Register your models here.


# class ProductAdmin(admin.ModelAdmin):
class ProductAdmin(MaterialModelAdmin):
    list_display = ['id', 'name', 'category', 'price']


# class OrderAdmin(admin.ModelAdmin):
class OrderAdmin(MaterialModelAdmin):
    list_display = ['id', 'name', 'email', 'date', 'paid']


# class OrderItemAdmin(admin.ModelAdmin):
class OrderItemAdmin(MaterialModelAdmin):
    list_display = ['id', 'price', 'quantity', 'product']


# class LineItemAdmin(admin.ModelAdmin):
class LineItemAdmin(MaterialModelAdmin):
    list_display = ['id', 'price', 'quantity', 'date_added', 'order']


# admin.site.register(Product, ProductAdmin)
# admin.site.register(Order, OrderAdmin)
# admin.site.register(CartItem, OrderItemAdmin)
# admin.site.register(LineItem, LineItemAdmin)
site.register(Product, ProductAdmin)
site.register(Order, OrderAdmin)
site.register(CartItem, OrderItemAdmin)
site.register(LineItem, LineItemAdmin)
