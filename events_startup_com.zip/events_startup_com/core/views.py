from django.shortcuts import render, HttpResponse, redirect, get_object_or_404, reverse
from django.contrib import messages
from .models import Product, Order, LineItem
from .forms import CartForm, CheckoutForm
from . import cart
from .cart import (add_item_to_cart, get_all_cart_items,
                   item_count, subtotal, remove_item, update_item, clear)
from django.conf import settings
from decimal import Decimal
from paypal.standard.forms import PayPalPaymentsForm
from django.views.decorators.csrf import csrf_exempt


def home(request):
    return render(request, 'core/main.html')


def speed_date(request):
    return render(request, 'core/speed_date.html')


def agenda(request):
    return render(request, 'core/agenda.html')


def tickets(request):
    all_products = Product.objects.all()
    single_tickets = all_products.filter(category='single')
    group_tickets = all_products.filter(category='group')
    startup_tickets = all_products.filter(category='startups')
    exhibitors_tickets = all_products.filter(category='exhibitors')
    investors_tickets = all_products.filter(category='investors')
    template = 'core/tickets.html'
    context = {
        'single_tickets': single_tickets,
        'group_tickets': group_tickets,
        'startup_tickets': startup_tickets,
        'exhibitors_tickets': exhibitors_tickets,
        'investors_tickets': investors_tickets,
    }
    return render(request, template, context)


def ticket_to_cart(request, product_id, product_slug):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = CartForm(request, request.POST or None, request.FILES or None)
        if form.is_valid():
            request.form_data = form.cleaned_data
            add_item_to_cart(request)
            return redirect('show_cart')
    form = CartForm(request, initial={'product_id': product.id, })
    return render(request, 'core/ticket_detail.html', {
        'product': product,
        'form': form,
    })


def show_cart(request):
    if request.method == 'POST':
        if request.POST.get('submit') == 'Update':
            update_item(request)
            messages.add_message(request, messages.INFO, 'Cart is updated')
        if request.POST.get('submit') == 'Remove':
            remove_item(request)
            messages.add_message(request, messages.INFO,
                                 'Cart Item is Removed')

    cart_items = get_all_cart_items(request,)
    cart_subtotal = subtotal(request)
    template = 'core/cart.html'
    context = {
        'cart_items': cart_items,
        'cart_subtotal': cart_subtotal,
    }
    return render(request, template, context)


def checkout(request):
    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            o = Order(
                name=cleaned_data.get('name'),
                email=cleaned_data.get('email'),
            )
            o.save()
            all_items = get_all_cart_items(request)
            for cart_item in all_items:
                li = LineItem(
                    product_id=cart_item.product_id,
                    price=cart_item.price,
                    quantity=cart_item.quantity,
                    order_id=o.id
                )

                li.save()

            clear(request)

            request.session['order_id'] = o.id
            messages.add_message(request, messages.SUCCESS, 'Order Placed!')
            return redirect(reverse('process_payment'))

    else:
        form = CheckoutForm()
        return render(request, 'core/checkout.html', {'form': form})


def process_payment(request):
    order_id = request.session.get('order_id')
    order = get_object_or_404(Order, id=order_id)
    host = request.get_host()
    paypal_dict = {
        'business': settings.PAYPAL_RECEIVER_EMAIL,
        'amount': '%.2f' % order.total_cost().quantize(
            Decimal('.01')),
        'item_name': 'Order {}'.format(order.id),
        'invoice': str(order.id),
        'custom': 'transaction successfull',
        'currency_code': 'INR',
        'notify_url': 'http://{}{}'.format(host, reverse('paypal-ipn')),
        'return_url': 'http://{}{}'.format(host, reverse('payment_done')),
        'cancel_return': 'http://{}{}'.format(host, reverse('payment_cancelled')),
    }

    form = PayPalPaymentsForm(initial=paypal_dict)
    return render(request, 'core/process_payment.html', {'order': order, 'form': form})


@csrf_exempt
def payment_done(request):
    return render(request, 'core/payment_done.html')


@csrf_exempt
def payment_canceled(request):
    return render(request, 'core/payment_cancelled.html')
