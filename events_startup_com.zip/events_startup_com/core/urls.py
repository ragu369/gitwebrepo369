from django.urls import path
from . import views
# from users import views as user_views

urlpatterns = [
    path('', views.home, name='main'),
    path('speed-date/', views.speed_date, name='speed_date'),
    path('agenda/', views.agenda, name='agenda'),
    path('tickets/', views.tickets, name='tickets'),
    path('cart/', views.show_cart, name='show_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('ttc/<int:product_id>/<slug:product_slug>/',
         views.ticket_to_cart, name='ticket_to_cart'),
    path('process-payment/', views.process_payment, name='process_payment'),
    path('payment-done/', views.payment_done, name='payment_done'),
    path('payment-cancelled/', views.payment_canceled, name='payment_cancelled'),
]
