from django.apps import AppConfig


class CoreConfig(AppConfig):
    name = 'core'
    icon_name = 'person'

    def ready(self):
        # import signal handlers
        import core.signals