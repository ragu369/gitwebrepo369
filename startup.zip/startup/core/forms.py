from django import forms
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm, SetPasswordForm
from .models import Order, CustomUser, Profile, Enquiry
from bootstrap_modal_forms.mixins import PopRequestMixin, CreateUpdateAjaxMixin


class CustomPasswordChangeForm(PasswordChangeForm):
    class Meta:
        fields = ['old_password', 'new_password1', 'new_password2']

    def __init__(self, *args, **kwargs):
        super(CustomPasswordChangeForm, self).__init__(*args, **kwargs)
        self.fields['new_password1'].help_text = None


class CustomSetPasswordForm(SetPasswordForm):
    class Meta:
        fields = ['new_password1', 'new_password2']

    def __init__(self, *args, **kwargs):
        super(CustomPasswordChangeForm, self).__init__(*args, **kwargs)
        self.fields['new_password1'].help_text = None


class UserRegisterForm(UserCreationForm):

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2', ]
        help_texts = {
            'username': None
        }

    def __init__(self, *args, **kwargs):
        super(UserRegisterForm, self).__init__(*args, **kwargs)
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None


class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField(max_length=100, required=False,
                             help_text='Required. Inform a valid email address.')

    class Meta:
        model = CustomUser
        fields = ['username', 'email', ]


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['birth_date', 'image', ]


class EnquiryForm(PopRequestMixin, CreateUpdateAjaxMixin, forms.ModelForm):
    name = forms.CharField(required=False, max_length=150, help_text='150 char max',
                           label='Name', widget=forms.TextInput(attrs={'placeholder': 'Your Name'}),)
    email = forms.EmailField(required=True, label='Email ID', help_text="valid email-id like 'example@gmail.com'",
                             widget=forms.TextInput(attrs={'placeholder': 'Your Email'}),)
    phone = forms.CharField(required=False, max_length=50, label='Phone Number',
                            widget=forms.TextInput(attrs={'placeholder': 'Your Phone/moble number'}),)
    enquiry = forms.CharField(required=True, widget=forms.Textarea())

    class Meta:
        model = Enquiry
        fields = ['name', 'email', 'phone', 'enquiry']


class CartForm(forms.Form):
    quantity = forms.IntegerField(initial='1', widget=forms.NumberInput(attrs={'class':
                                                                               'uk-input uk-text-center uk-form-width-small tm-quantity-input', 'maxlength': 3}))
    product_id = forms.IntegerField(widget=forms.HiddenInput)

    def __init__(self, request, *args, **kwargs):
        self.request = request
        super(CartForm, self).__init__(*args, **kwargs)


class CheckoutForm(forms.ModelForm):
    class Meta:
        model = Order
        exclude = ('paid',)

        # widgets = {
        #     'address': forms.Textarea(attrs={'row': 5, 'col': 8}),
        # }
