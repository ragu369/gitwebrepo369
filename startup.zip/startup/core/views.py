from django.shortcuts import render, HttpResponse, redirect, get_object_or_404, reverse
from django.contrib import messages
from .models import Product, Order, LineItem
from .forms import CartForm, CheckoutForm, UserCreationForm, UserRegisterForm, UserUpdateForm, ProfileUpdateForm, EnquiryForm, CustomPasswordChangeForm, CustomSetPasswordForm
from django.contrib.auth.views import PasswordChangeView, PasswordResetConfirmView
from . import cart
from .cart import (add_item_to_cart, get_all_cart_items,
                   item_count, subtotal, remove_item, update_item, clear)
from django.conf import settings
from decimal import Decimal
from paypal.standard.forms import PayPalPaymentsForm
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.urls import reverse_lazy
from bootstrap_modal_forms.generic import BSModalCreateView


def home(request):
    return render(request, 'core/main.html')


def speed_date(request):
    return render(request, 'core/speed_date.html')


def agenda(request):
    return render(request, 'core/agenda.html')

def profile_settings(request):
    return render(request, 'core/profile_settings.html')


def tickets(request):
    all_products = Product.objects.all()
    single_tickets = all_products.filter(category='single')
    group_tickets = all_products.filter(category='group')
    startup_tickets = all_products.filter(category='startups')
    exhibitors_tickets = all_products.filter(category='exhibitors')
    investors_tickets = all_products.filter(category='investors')
    template = 'core/tickets.html'
    context = {
        'single_tickets': single_tickets,
        'group_tickets': group_tickets,
        'startup_tickets': startup_tickets,
        'exhibitors_tickets': exhibitors_tickets,
        'investors_tickets': investors_tickets,
        'section': 'tickets',
    }
    return render(request, template, context)


@login_required
def ticket_to_cart(request, product_id, product_slug):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = CartForm(request, request.POST or None, request.FILES or None)
        if form.is_valid():
            request.form_data = form.cleaned_data
            add_item_to_cart(request)
            return redirect('show_cart')
    form = CartForm(request, initial={'product_id': product.id, })
    return render(request, 'core/ticket_detail.html', {
        'product': product,
        'form': form,
    })


def show_cart(request):
    if request.method == 'POST':
        if request.POST.get('submit') == 'Update':
            update_item(request)
            messages.add_message(request, messages.INFO, 'Cart is updated')
        if request.POST.get('submit') == 'Remove':
            remove_item(request)
            messages.add_message(request, messages.INFO,
                                 'Cart Item is Removed')

    cart_items = get_all_cart_items(request,)
    cart_subtotal = subtotal(request)
    template = 'core/cart.html'
    context = {
        'cart_items': cart_items,
        'cart_subtotal': cart_subtotal,
    }
    return render(request, template, context)


@login_required
def checkout(request):
    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            o = Order(
                name=cleaned_data.get('name'),
                email=cleaned_data.get('email'),
            )
            o.save()
            all_items = get_all_cart_items(request)
            for cart_item in all_items:
                li = LineItem(
                    product_id=cart_item.product_id,
                    price=cart_item.price,
                    quantity=cart_item.quantity,
                    order_id=o.id
                )

                li.save()

            clear(request)

            request.session['order_id'] = o.id
            messages.add_message(request, messages.SUCCESS, 'Order Placed!')
            return redirect(reverse('process_payment'))

    else:
        form = CheckoutForm()
        return render(request, 'core/checkout.html', {'form': form})


@login_required
def process_payment(request):
    order_id = request.session.get('order_id')
    order = get_object_or_404(Order, id=order_id)
    host = request.get_host()
    paypal_dict = {
        'business': settings.PAYPAL_RECEIVER_EMAIL,
        'amount': '%.2f' % order.total_cost().quantize(
            Decimal('.01')),
        'item_name': 'Order {}'.format(order.id),
        'invoice': str(order.id),
        'custom': 'transaction successfull',
        'currency_code': 'INR',
        'notify_url': 'http://{}{}'.format(host, reverse('paypal-ipn')),
        'return_url': 'http://{}{}'.format(host, reverse('payment_done')),
        'cancel_return': 'http://{}{}'.format(host, reverse('payment_cancelled')),
    }

    form = PayPalPaymentsForm(initial=paypal_dict)
    return render(request, 'core/process_payment.html', {'order': order, 'form': form})


@csrf_exempt
def payment_done(request):
    return render(request, 'core/payment_done.html')


@csrf_exempt
def payment_canceled(request):
    return render(request, 'core/payment_cancelled.html')


def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            messages.success(
                request, f'Your account has been created! You are now able to log in')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'core/signup.html', {'form': form, 'section': 'signup'})


@login_required
def profile(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST or None, instance=request.user)
        p_form = ProfileUpdateForm(
            request.POST or None, request.FILES or None, instance=request.user.profile)
        # subs_form = SubscriptionForm(request.POST or None)

        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            # request.session['subscription_plan'] = request.POST.get('plans')
            messages.success(request, f'Your account has been updated!')
            return redirect('profile')
    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=request.user.profile)
        # subs_form = SubscriptionForm()
    context = {
        'u_form': u_form,
        'p_form': p_form,
        'section': 'profile'
        # 'subs_form': subs_form,
    }
    return render(request, 'core/profile.html', context)


class EnquiryView(BSModalCreateView):
    form_class = EnquiryForm
    template_name = 'core/enquiry.html'
    success_message = 'Success: Submited!. We will get back to you regarding your enquiry.'
    success_url = reverse_lazy('main')


class CustomPasswordChangeView(PasswordChangeView):
    form_class = CustomPasswordChangeForm
    template_name = 'core/password_change_form.html'


class CustomPasswordChangeView(PasswordResetConfirmView):
    form_class = CustomSetPasswordForm
    template_name = 'core/password_change_form.html'
# def enquiry(request):
#     if request.method == 'POST':
#         form = EnquiryForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(
#                 request, f'We will get back to you regarding your enquiry')
#             return redirect('enquiry')
#     else:
#         form = EnquiryForm()
#     return render(request, 'core/enquiry.html', {'form': form})
