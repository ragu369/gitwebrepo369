from django.contrib import admin
# from material.admin.options import MaterialModelAdmin
# from material.admin.sites import site
from .models import Product, Order, CartItem, LineItem, Enquiry, CustomUser, Profile

# Register your models here.


class UserAdmin(admin.ModelAdmin):
    list_display = ['username', 'password', 'email']


class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'image', 'birth_date', ]


class ProductAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'category', 'price']


class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'email', 'date', 'paid']


class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['id', 'price', 'quantity', 'product']


class LineItemAdmin(admin.ModelAdmin):
    list_display = ['id', 'price', 'quantity', 'date_added', 'order']


class EnquiryAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'phone', 'enquiry', ]


admin.site.register(Product, ProductAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(CartItem, OrderItemAdmin)
admin.site.register(LineItem, LineItemAdmin)
admin.site.register(Enquiry, EnquiryAdmin)
admin.site.register(CustomUser, UserAdmin)
admin.site.register(Profile, ProfileAdmin)


# class UserAdmin(MaterialModelAdmin):
#     list_display = ['username', 'password', 'email']


# class ProfileAdmin(MaterialModelAdmin):
#     list_display = ['user', 'image', 'birth_date', ]


# class ProductAdmin(MaterialModelAdmin):
#     list_display = ['id', 'name', 'category', 'price']


# class OrderAdmin(MaterialModelAdmin):
#     list_display = ['id', 'name', 'email', 'date', 'paid']


# class OrderItemAdmin(MaterialModelAdmin):
#     list_display = ['id', 'price', 'quantity', 'product']


# class LineItemAdmin(MaterialModelAdmin):
#     list_display = ['id', 'price', 'quantity', 'date_added', 'order']


# class EnquiryAdmin(MaterialModelAdmin):
#     list_display = ['name', 'email', 'phone', 'enquiry', ]


# site.register(Product, ProductAdmin)
# site.register(Order, OrderAdmin)
# site.register(CartItem, OrderItemAdmin)
# site.register(LineItem, LineItemAdmin)
# site.register(Enquiry, EnquiryAdmin)
# site.register(CustomUser, UserAdmin)
# site.register(Profile, ProfileAdmin)
