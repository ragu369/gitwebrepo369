from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
# from users import views as user_views

urlpatterns = [
    path('startup.com/main', views.home, name='main'),
    path('speed-date/', views.speed_date, name='speed_date'),
    path('agenda/', views.agenda, name='agenda'),
    path('tickets/', views.tickets, name='tickets'),
    path('cart/', views.show_cart, name='show_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('ttc/<int:product_id>/<slug:product_slug>/',
         views.ticket_to_cart, name='ticket_to_cart'),
    path('process-payment/', views.process_payment, name='process_payment'),
    path('payment-done/', views.payment_done, name='payment_done'),
    path('payment-cancelled/', views.payment_canceled, name='payment_cancelled'),
    path('signup/', views.register, name='signup'),
    # path('enquiry/', views.enquiry, name='enquiry'),
    path('enquiry/', views.EnquiryView.as_view(), name='enquiry'),
    path('settings/', views.profile_settings, name='profile_settings'),
    path('login/',
         auth_views.LoginView.as_view(
             template_name='core/login.html'),
         name='login'),
    path('logout/',
         auth_views.LogoutView.as_view(
             template_name='core/logout.html'),
         name='logout'),
    # change password url
    # path('password_change/',
    #      auth_views.PasswordChangeView.as_view(
    #          template_name='core/password_change_form.html'),
    #      name='password_change'),
    path('password_change/',
         views.CustomPasswordChangeView.as_view(), name='password_change'),
    path('password_change/done/',
         auth_views.PasswordChangeDoneView.as_view(
             template_name='core/password_change_done.html'),
         name='password_change_done'),
    # reset password url
    path('password-reset/',
         auth_views.PasswordResetView.as_view(
             template_name='core/password_reset_form.html'),
         name='password_reset'),
    path('password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='core/password_reset_done.html'),
         name='password_reset_done'),
    # path('password-reset/confirm/<uidb64>/<token>',
    #      auth_views.PasswordResetConfirmView.as_view(
    #          template_name='register/password_reset_confirm.html'),
    #      name='password_reset_confirm'),
    path('password-reset/confirm/<uidb64>/<token>',
         views.CustomPasswordChangeView.as_view(),
         name='password_reset_confirm'),
    path('password-reset/complete/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='core/password_reset_complete.html'),
         name='password_reset_complete'),
]
